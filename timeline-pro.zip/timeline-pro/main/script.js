const img1 = document.getElementById("img1");
const img2 = document.getElementById("img2");
const img3 = document.getElementById("img3");
const img4 = document.getElementById("img4");
const img5 = document.getElementById("img5");
const dot = document.getElementById("dot");
const dot2 = document.getElementById("dot2");
const dot3 = document.getElementById("dot3");
const dot4 = document.getElementById("dot4");
const dot5 = document.getElementById("dot5");
const h1 = document.getElementById("h1");
const para = document.getElementById("para");
const div1 = document.getElementById("div1");
const div2 = document.getElementById("div2");
const div3 = document.getElementById("div3");
const div4 = document.getElementById("div4");
const div5 = document.getElementById("div5");
const ver = document.getElementById("ver");
const ver2 = document.getElementById("ver2");
const ver3 = document.getElementById("ver3");
const ver4 = document.getElementById("ver4");
const ver5 = document.getElementById("ver5");
const ver6 = document.getElementById("ver6");





img1.addEventListener('click',()=>{
   document.getElementById("h1").innerHTML = "Collection"
   img1.style.borderColor= 'green'
   img2.style.borderColor= 'black'
   dot.style.color = "green"
   dot2.style.color = "black"
   dot4.style.color = "black"

   div1.style.display="block"
   div2.style.display="none"
   div3.style.display="none"
   div4.style.display="none"
   div5.style.display="none"
   ver.style.display="none"
   ver2.style.display="none"
   ver3.style.display="block"
   ver4.style.display="block"
   ver5.style.display="block"
   ver6.style.display="block"




  
   
   
   
});
 
img1.addEventListener('click',()=>{
    document.getElementById("para").innerHTML = "Explore our diverse eCommerce collection, curated to meet your every need. From fashion to electronics, find quality products that elevate your online shopping experience."
 });

img2.addEventListener('click',()=>{
    document.getElementById("h1").innerHTML = "Sorting "
    img2.style.borderColor= 'green'
    img1.style.borderColor= 'black'
    dot.style.color = "black"
    dot2.style.color = "green"
    dot3.style.color = "black"
    dot5.style.color = "black"
   div2.style.display="block"
   div3.style.display="none"
   div4.style.display="none"
   div5.style.display="none"
   div1.style.display="none"
   ver3.style.display="none"
   ver2.style.display="none"
   ver.style.display="block"
   ver4.style.display="block"
   ver5.style.display="block"
   ver6.style.display="block"
   
   


   
   

 });

 img2.addEventListener('click',()=>{
    document.getElementById("para").innerHTML = "Effortlessly navigate through our eCommerce collection with intuitive sorting options, ensuring you find exactly what you're looking for quickly and efficiently"
 });

 img3.addEventListener('click',()=>{
    document.getElementById("h1").innerHTML = "Processing"
    dot3.style.color = "green"
    dot.style.color = "black"
    dot2.style.color = "black"
    dot4.style.color = "black"
    dot5.style.color = "black"
    div2.style.display="none"
   div3.style.display="block"
   div4.style.display="none"
   div5.style.display="none"
   div1.style.display="none"
   ver.style.display="block"
   ver2.style.display="block"
   ver3.style.display="none"
   ver4.style.display="none"
   ver5.style.display="none"
   
 });

 img3.addEventListener('click',()=>{
    document.getElementById("para").innerHTML = "Streamline your shopping experience with our seamless processing system. From checkout to delivery, we ensure efficient handling of your orders for a hassle-free experience"
 });

 img4.addEventListener('click',()=>{
    document.getElementById("h1").innerHTML = "Recovery"
    dot4.style.color = "green"
    dot3.style.color = "black"
    dot.style.color = "black"
    dot2.style.color = "black"
    dot5.style.color = "black"
    div1.style.display="none"

    div2.style.display="none"
    div3.style.display="none"
    div4.style.display="block"
    div5.style.display="none"
    div1.style.display="none"
    ver.style.display="block"
    ver3.style.display="block"
    ver4.style.display="none"
    ver5.style.display="none"
    ver6.style.display="none"
 });

 img4.addEventListener('click',()=>{
    document.getElementById("para").innerHTML = "Experience peace of mind with our robust recovery system. In case of any issues, we've got you covered, ensuring a smooth journey from setback to satisfaction."
 });

 img5.addEventListener('click',()=>{
    document.getElementById("h1").innerHTML = "Reporting"
    dot5.style.color = "green"
    dot4.style.color = "black"
    dot3.style.color = "black"
    dot.style.color = "black"
    dot2.style.color = "black"
    div1.style.display="none"
    ver.style.display="block"
    ver4.style.display="block"

    
    div2.style.display="none"
    div3.style.display="none"
    div4.style.display="none"
    div5.style.display="block"
    div1.style.display="none"
 });

 img5.addEventListener('click',()=>{
    document.getElementById("para").innerHTML = "Gain valuable insights with our comprehensive reporting tools. Track your eCommerce performance, analyze trends, and make informed decisions to optimize your business strategy effectively."
 });